package practicalexam;

/**
 *
 * @author LocNgD <locndse160199@fpt.edu.vn>
 */
public class PracticalExam {

    public static void main(String[] args) {
        
        problemOne();
        problemTwo();
        problemThree();
    }
    
    
    static void problemOne() {
        Prob1 p1 = new Prob1();
        p1.solve();
    }
    
    static void problemTwo() {
        Prob2 p2 = new Prob2();
        p2.solve();
    }
    
    static void problemThree() {
        Prob3 p3 = new Prob3();
        p3.solve();
    }
}
